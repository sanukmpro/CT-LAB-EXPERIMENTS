package com.example.exp8;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText editTextName;
    private RadioGroup radioGroupGender;
    private CheckBox checkBoxAccept;
    private Button buttonSubmit;
    private TextView textViewResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editTextName = findViewById(R.id.editTextName);
        radioGroupGender = findViewById(R.id.radioGroupGender);
        checkBoxAccept = findViewById(R.id.checkBoxAccept);
        buttonSubmit = findViewById(R.id.buttonSubmit);
        textViewResult = findViewById(R.id.textViewResult);

        buttonSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = editTextName.getText().toString().trim();

                if (name.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Please enter your name.",
                            Toast.LENGTH_SHORT).show();
                    return;
                }

                String gender;
                int selectedGenderId = radioGroupGender.getCheckedRadioButtonId();
                if (selectedGenderId == -1) {
                    gender = "Not selected";
                } else {
                    RadioButton selectedGender = findViewById(selectedGenderId);
                    gender = selectedGender.getText().toString();
                }

                boolean isAccepted = checkBoxAccept.isChecked();
                if (!isAccepted) {
                    Toast.makeText(MainActivity.this, "You must accept the terms and conditions.",
                            Toast.LENGTH_SHORT).show();
                    return;
                }

                String resultMessage = "Name: " + name +
                        "\nGender: " + gender +
                        "\nAccepted Terms: " + (isAccepted ? "Yes" : "No");

                textViewResult.setText(resultMessage);
            }
        });
    }
}
