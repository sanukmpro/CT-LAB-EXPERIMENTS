package com.example.exp7;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class relativeLayout extends AppCompatActivity {
    Button rb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_relative_layout);

        rb = findViewById(R.id.rLogin);

        rb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Example: navigate back to MainActivity
                Intent intent = new Intent(relativeLayout.this, login.class);
                startActivity(intent);
            }
        });
    }
}
