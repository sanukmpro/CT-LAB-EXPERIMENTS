package com.example.dbapp;

import androidx.appcompat.app.AppCompatActivity;
import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private EditText edUserName, edUserEmail, edUserPassword;
    private Button btnRegister;
    private SQLiteDatabase db;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edUserEmail = findViewById(R.id.id_useremail);
        edUserName = findViewById(R.id.id_username);
        edUserPassword = findViewById(R.id.id_user_password);
        btnRegister = findViewById(R.id.id_btn_register);

        // Initialize your database (replace with your DB helper class)
        DBHelper dbHelper = new DBHelper(this);
        db = dbHelper.getWritableDatabase();

        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                registerUser();
            }
        });
    }

    private void registerUser() {
        String userName = edUserName.getText().toString().trim();
        String userPassword = edUserPassword.getText().toString().trim();
        String userEmail = edUserEmail.getText().toString().trim();

        if (userName.isEmpty() || userPassword.isEmpty() || userEmail.isEmpty()) {
            Toast.makeText(MainActivity.this, "Please fill all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        ContentValues values = new ContentValues();
        values.put("username", userName);
        values.put("email", userEmail);
        values.put("password", userPassword);

        long id = db.insert("userdetails", null, values);

        if (id != -1) {
            Toast.makeText(MainActivity.this, "User registered successfully! Record ID: " + id, Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(MainActivity.this, "Registration failed", Toast.LENGTH_SHORT).show();
        }
    }
}
